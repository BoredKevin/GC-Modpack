# goodCompany Modpack
The official Good Company modpack, includes many QoL & funny changes.

## CHANGELOG

### v0.0.2

Updated README & Pack Description

### v0.0.1

