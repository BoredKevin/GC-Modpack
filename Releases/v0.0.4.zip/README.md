# goodCompany Modpack
The official Good Company modpack, includes many QoL & funny changes.

## CHANGELOG

### v0.0.4

Added [Lategame Upgrades](https://thunderstore.io/c/lethal-company/p/malco/Lategame_Upgrades/) by malco

Fixed Broken Mods

`+ malco-Lategame_Upgrades-2.8.5`
`+ Evaisa-HookGenPatcher-0.0.5`
`+ Evaisa-LethalLib-0.9.0`
`- Clementinise-CustomSounds-2.2.0`
`- Ozone-Lockdown-1.0.3`
`- Ozone-BepInUtils-1.2.1`

### v0.0.3

Added [YouTubeBoombox](https://thunderstore.io/c/lethal-company/p/steven4547466/YoutubeBoombox/) by steven4547466

`+ steven4547466-YoutubeBoombox-1.5.0`
`+ 2018-LC_API-3.1.0`

### v0.0.2

Updated README & Pack Description

`- README.md`
`+ README.md`

### v0.0.1

